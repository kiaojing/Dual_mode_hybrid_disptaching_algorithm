import GA
import numpy as np
import km_algorithm
import sys
import util
sys.setrecursionlimit(100000)
mapsize =util.mapsize
start, hot_list = util.start,util.hot_list
print(hot_list)
result= GA.da_main(start,hot_list)


def get_start_end():
    end_grid =[]
    for i in range(mapsize[0]):
        for j in range(mapsize[1]):
            if hot_list[i][j]>0:
                end_grid.append([i,j])
    start_grid = start
    return start_grid,end_grid

def km_cal():
    global result
    rest = []
    over = []
    s,e= get_start_end()
    F_LIST = np.array([round(i[1]) for i in result]).reshape(len(s),len(e))
    #ROUTE_LIST =np.array([i[0] for i in result],dtype=object).reshape(len(s),len(e))
    ROUTE_LIST =[i[0] for i in result]
    km =km_algorithm.KM()
    min_ = km.compute(F_LIST, True)
    for i in min_:
        if i[1] == -1:
            rest.append(i)
        else:
            over.append(i)
    # sum_f = sum(F_LIST[[i[0] for i in over], [i[1] for i in over]])
    # 更新start    i[0]就是匹配完成的车辆第【0】辆车  删除
    h = 0
    for i in over:
        del start[i[0]-h]
        del result[(i[0]-h)*len(e):(i[0]-h+1)*len(e)]
        h +=1
    # 更新end，(调度目的地确定的start删掉，热度为0的end删掉)
    for i in e:
        if hot_list[i[0]][i[1]]==1:
            result =[j for j in result if j[0][-1] != i]
        hot_list[i[0]][i[1]]-=1
    return over,rest,ROUTE_LIST,len(e)
if __name__ ==  '__main__':
    num =[]
    for i in range(999):
        if sum(num)>=89:
            break
        else:
            a,b,r = km_cal()
            num.append(len(a))
            print(sum(num))
        # print(a)
        # print(b)
        # print(len(start))
        # print(len(result))






