import random 
import numpy as np 
import math 
import pandas as pd
import matplotlib.pyplot as plt
import util
import warnings
warnings.filterwarnings('ignore')
mapsize =util.mapsize
start, hot_list = util.start,util.hot_list
result = []
class Fiter:
    def __init__(self):
        self.b = 1  

    def function(self, a):  
        for i in a:  
            a = a[a.index(i) + 1:]  
            if i in a:  
                return i, 1  
            else: 
                pass
        return 0, 0  

    def fiter(self, a):
        while (self.b == 1):  
            (i, self.b) = self.function(a)  
            c = [j for j, x in enumerate(a) if x == i]  
            if c==[]:
                break
            a = a[0:c[0]] + a[c[-1]:]  
        return a
fiter = Fiter()#实例化对象

class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __eq__(self, other): 
        if((self.x == other.x )and (self.y == other.y)):
            return  True
        else:
            return False
    def __ne__(self, other):
        pass

class Map():


    def __init__(self,row,col,start,end):
        self.start_point = Point(start[0],start[1])
        self.end_point = Point(end[0],end[1])
        self.data = []
        self.row = row
        self.col = col
    def map_init(self):
        self.data = [[0 for i in range(self.col)] for j in range(self.row)]
        # for i in range(self.row):
        #     for j in range(self.col):
        #         print(self.data[i][j],end=' ')
        #     print('')
    def map_Obstacle(self,num):

        self.num = num
        for i in range(self.num):
            self.data[random.randint(0,self.row-1)][random.randint(0,self.col-1)] = 1
        if self.data[0][0] == 1:        
            self.data[0][0] = 0

        if self.data[self.row-1][0] == 1:
            self.data[self.row-1][0] = 0

        if self.data[0][self.col-1] == 1:
            self.data[0][self.col - 1] = 0

        if self.data[self.row-1][self.col - 1] == 1:
            self.data[self.row - 1][self.col - 1] = 0
        # for i in range(self.row):       #显示出来
        #     for j in range(self.col):
        #         print(self.data[i][j],end=' ')
        #     print('')
        return self.data
class Population():
    def __init__(self,row,col,num,NP,start,end):
        self.row = row
        self.col = col
        self.num = num
        self.NP = NP
        self.p_start = start[0]*col+start[1]# 起始点序号  10进制编码
        #print(self.p_start)
        self.p_end = end[0]*col+end[1]  # 终点序号 10进制编码
        self.xs = (self.p_start) // (self.col)  # 行
        self.ys = (self.p_start) % (self.col)  # 列
        self.xe = (self.p_end) // (self.col)  # 终点所在的行
        self.ye = (self.p_end) % (self.col)
        self.map_start = Map(self.row, self.col,start,end) 
        self.map_start.map_init()
        self.map = self.map_start.map_Obstacle(self.num)

        self.can = []  
        self.popu = [[0 for i in range(self.col)]
                     for j in range(self.NP)] 
        # self.popu = []
        self.end_popu = []

    def Population_Init(self):
        for i in range(self.NP):      
            j = 0
            for xk in range(0,self.row):  
                self.can = []             
                for yk in range(0,self.col):   #
                    num = (yk) + (xk) * self.col
                    if self.map_start.data[xk][yk] == 0:
                        self.can.append(num)
                # print(self.can,'自由点\n')
                length = len(self.can)     
                # print(length)
                self.popu[i][j] = (self.can[random.randint(0,length-1)])
                j += 1
            self.popu[i][0] = self.p_start
            self.popu[i][-1] = self.p_end

            temp = self.Generate_Continuous_Path(self.popu[i])
            if temp != []:   
                temp = fiter.fiter(temp)    
                self.end_popu.append(temp)
            # print(self.end_popu, end='\n')
        # print('测试1',self.popu,end='\n')
        return self.end_popu
    def Generate_Continuous_Path(self,old_popu):#生成连续的路径个体
        '''
        :param old_popu: 未进行连续化的一条路径
        :return:        无返回                   # 已经连续化的一条路径
        '''
        self.new_popu = old_popu
        self.flag = 0
        self.lengh = len(self.new_popu)  
        i = 0
        # print("lengh =",self.lengh )
        while i!= self.lengh-1:     
            x_now = (self.new_popu[i]) // (self.col)  
            y_now = (self.new_popu[i]) % (self.col)  
            x_next =  (self.new_popu[i+1]) // (self.col) 
            y_next =  (self.new_popu[i+1]) % (self.col)
            #最大迭代次数
            max_iteration = 0
            while max(abs(x_next - x_now), abs(y_next - y_now)) != 1:
                x_insert = math.ceil((x_next + x_now) // 2)      #行
                y_insert = math.ceil((y_next + y_now) // 2) 
                # print("x_insert = ",x_insert,"\ty_insert = ",y_insert)
                flag1 = 0

                if self.map_start.data[x_insert][y_insert] == 0:  
                    num_insert = (y_insert) + (x_insert) * self.col 
                    self.new_popu.insert(i+1,num_insert)
                    # print(self.new_popu)
                    # print(num_insert)
                else:
                    if (x_insert + 1 < self.row)and flag1 == 0:    
                        if ((self.map_start.data[x_insert+1][y_insert] == 0)
                            and (((y_insert) + (x_insert+1) * self.col) not in self.new_popu)):
                            num_insert = (y_insert) + (x_insert+1) * self.col 
                            self.new_popu.insert(i + 1, num_insert) 
                            flag1 = 1   

                    if (y_insert + 1 < self.col)and flag1 == 0: 
                        if ((self.map_start.data[x_insert][y_insert+1] == 0)
                            and (((y_insert+1) + (x_insert) * self.col) not in self.new_popu)):
                            num_insert = (y_insert+1) + (x_insert) * self.col 
                            self.new_popu.insert(i + 1, num_insert) 
                            flag1 = 1  
                            # print('右方插入',num_insert)

                    if (x_insert - 1 > 0) and flag1 == 0:  
                        if ((self.map_start.data[x_insert-1][y_insert] == 0)
                            and (((y_insert) + (x_insert-1) * self.col) not in self.new_popu)):
                            num_insert = (y_insert) + (x_insert-1) * self.col  
                            self.new_popu.insert(i + 1, num_insert) 
                            flag1 = 1
                            # print('上方插入',num_insert)

                    if (y_insert - 1 > 0)and flag1 == 0: 
                        if ((self.map_start.data[x_insert][y_insert-1] == 0)
                            and (((y_insert-1) + (x_insert) * self.col) not in self.new_popu)):
                            num_insert = (y_insert-1) + (x_insert) * self.col 
                            self.new_popu.insert(i + 1, num_insert)
                            flag1 = 1  
                            # print('左方插入',num_insert)
                    if flag1 == 0:  
                        self.new_popu = []
                        break
                x_next = num_insert//self.col
                y_next = num_insert%self.col
                # x_next = x_insert
                # y_next = y_insert
                max_iteration += 1
                if max_iteration > 20:
                    self.new_popu = []  
                    break
            if self.new_popu == []:
                break
            self.lengh = len(self.new_popu)
            i = i+1
        # print(self.new_popu,'连续')
        return  self.new_popu#返回的是一条路径

def calvalue(popu,col):
    hang = len(popu)
    value = []
    for i in range(hang):
        value.append(0)
        single_popu = popu[i] 
        single_lengh = len(single_popu)
        for j in range(single_lengh-1):
            x_now = (single_popu[j]) // (col) 
            y_now = (single_popu[j]) % (col) 
            x_next = (single_popu[j + 1]) // (col)
            y_next = (single_popu[j + 1]) % (col)
            # print(x_next,y_next)

            if abs(x_now - x_next) + abs(y_now - y_next) == 1:
                if hot_list[x_next][y_next]>0:
                    value[i] = (value[i]+1)/hot_list[x_next][y_next]
                if hot_list[x_next][y_next]==0:
                    value[i] = (value[i]+1)/0.5
                if hot_list[x_next][y_next]<0:
                    value[i] = 100
            elif max(abs(x_now - x_next),abs(y_now - y_next))>=2:
                value[i] = value[i] + 100
            else:
                if hot_list[x_next][y_next]>0:
                    value[i] = (value[i]+1.4)/hot_list[x_next][y_next]
                if hot_list[x_next][y_next]==0:
                    value[i] = (value[i]+1.4)/0.5
                if hot_list[x_next][y_next]<0:
                    value[i] = 100
        #print(value)
    return value

def selection(pop,value):
    now_value=[]
    P_value = []  
    random_deci = []
    new_popu = []   
    sum_value = 0 
    lengh = len(pop)
    for i in range(lengh):
        new_popu.append([])
    for i in value:     
        now_value.append(1/i)  
        sum_value += (1/i)
    for i in now_value:
        P_value.append(i/sum_value)
    P_value = np.cumsum(P_value)
    for i in range(lengh):
        random_deci.append(random.random())
    random_deci = sorted(random_deci)
    fitin = 0
    newin = 0
    while(newin<lengh): 
        if random_deci[newin] < P_value[fitin]:
            new_popu[newin] = pop[fitin]
            newin += 1
        else:
            fitin += 1
    return new_popu

def cross(parents,pc):
    children = []  
    single_popu_index_list = []
    lenparents = len(parents) 
    parity = lenparents % 2 
    for i in range(0,lenparents-1,2):  
        single_now_popu = parents[i] 
        single_next_popu = parents[i+1]
        children.append([])
        children.append([])
        index_content = list(set(single_now_popu).intersection(set(single_next_popu))) 
        num_rep = len(index_content)     
        if random.random() < pc and num_rep>=3:
            content = index_content[random.randint(0,num_rep-1)] 
            now_index = single_now_popu.index(content) 
            next_index = single_next_popu.index(content)
            children[i] = single_now_popu[0:now_index + 1] + single_next_popu[next_index + 1:]
            children[i+1] = single_next_popu[0:next_index + 1] + single_now_popu[now_index + 1:]
        else:
            children[i] = parents[i]
            children[i+1] = parents[i+1]
    if parity == 1:     
        children.append([]) 
        children[-1] = parents[-1]
    return children

def mutation(children,pm):
    row = len(children)  
    new_popu = []
    for i in range(row):
        temp = [] 
        while(temp == []): 
            single_popu = children[i]
            if random.random()<pm:
                col = len(single_popu)
                try:
                    first = random.randint(1,col-2) 
                    second = random.randint(1,col-2)
                except:
                    first=1
                    second=1
                if first != second :   
                    if(first<second):
                        single_popu = single_popu[0:first]+single_popu[second+1:]
                    else :
                        single_popu = single_popu[0:second] + single_popu[first+1:]
                temp = population.Generate_Continuous_Path(single_popu)
                if temp!= []:
                    new_popu.append(temp)

            else:       
                new_popu.append(single_popu)
    return new_popu
def main(start,end):
    global population
    population = Population(mapsize[0],mapsize[1],0,4,start,end)  

    popu = population.Population_Init()  #
    # print(popu,'连续路径')
    print(start,end)
    for i in range(10):    #迭代200代
        print('第%s代'%i)
        lastpopu = popu #上次的种群先保存起来
        value = calvalue(popu,population.col) 
        # print(value,'适应度值')

        new = selection(popu,value)
        # print(new,'新种群')
        # value = calvalue(new,population.col)
        # print(value,'新种群适应度值')
        child = cross(new,0.9)  #交叉  产生子代
        # print(child,'交叉子代')
        # value = calvalue(child,population.col) 
        # print(value,'子代适应度值')
        popu = mutation(child,0.1)
        values = calvalue(popu,population.col) 
        va.append(min(values))
        print(va)
        if popu == []:  
            popu = lastpopu
            break
        # print('第',i,'次迭代后的种群为：',popu)
    if popu == []:  
        print('无路径')
    else:
        value = calvalue(popu,population.col)
        minnum = value[0]
        for i in range(len(value)):
            if value[i] < minnum:
                minnum = value[i]
        popu = popu[value.index(minnum)]


        ###路径可视化
        # for i in popu:
        #     x = (i) // (population.map_start.col)  
        #     y = (i) % (population.map_start.col)
        #     population.map_start.data[x][y] = '*'   #将路径用*表示
        # print('\n规划地图')
        # for i in range(population.map_start.row):   #显示路径
        #     for j in range(population.map_start.col):
        #         print(population.map_start.data[i][j],end=' ')
        #     print('')
        # print('最短路径值为：',minnum)
        # print('最短路径为：',popu)

        #编码转格子
        route = []
        for i in popu:
            route.append([(i) // mapsize[0], (i) % mapsize[0]])
        result.append([route,minnum*100])

    plt.plot(range(len(va)),va)
    plt.savefig('a.png')
    return None
def da_main(start,hot_list):
    end = []
    for i in range(mapsize[0]):
        for j in range(mapsize[1]):
            if hot_list[i][j] > 0:
                end.append([i, j])
    save_duplicate = []

    #少样本车辆测试
    # start = [[2,2],[3,4],[2,2]]
    # end = [[2,2],[5,3]]
    start = [[3,2],]
    end =[[13,3],]
    print(len(start),len(end))

    for i in start:
        for j in end:
            if i in save_duplicate:
                result.append([[i,j],333])
            elif i==j:
                if hot_list[i[0]][i[1]] <0:
                    result.append([[i,i],100])
                elif hot_list[i[0]][i[1]] ==0:
                    result.append([[i,i],2])
                else:
                    result.append([[i,i],1/hot_list[i[0]][i[1]]])
            else:
                main(i,j)
        save_duplicate.append(i)

    #   将之前未计算的替换
    for i in range(len(result)):
        if result[i][1]==333:
            for j in result:
                if result[i][0][0]==j[0][0] and result[i][0][-1]==j[0][-1]:
                    result[i][0]=j[0]
                    result[i][1]=j[1]
                    break


    # F_LIST,ROUTE_LIST=[],[]
    # for i in result:
    #     F_LIST.append(round(i[1]))
    #     ROUTE_LIST.append(i[0])
    # F_LIST = np.array(F_LIST).reshape(len(start),len(end))
    # ROUTE_LIST =np.array(ROUTE_LIST,dtype=object).reshape(len(start),len(end))
    # F_LIST =F_LIST.tolist()
    # ROUTE_LIST = ROUTE_LIST.tolist()
    return result
if __name__ == '__main__':

    va = []
    print(hot_list)
    r = da_main(start,hot_list)
    print(r)
    print(len(r))




