import util
import numpy as np
import pandas as pd
import sys
import copy
import time
start_time = time.perf_counter()
#import dispatch

mapsize =util.mapsize
start, hot_table = util.start,util.hot_list
h_copy1 =copy.deepcopy(hot_table)
h_copy3 =copy.deepcopy(hot_table)
print(hot_table)
print('当前可用车辆数:',len(start))
print('--------------------')


for i in range(mapsize[0]):
    for j in range(mapsize[1]):
        h_copy1[i][j] = abs(h_copy1[i][j])
##  不调度的ROP
ROP_start=[]
for i in start:
    ROP_start.append(hot_table[i[0]][i[1]])
print('初始状态不调度的SDD:',sum(sum(h_copy1)))
print('初始状态不调度的ROP:',(sum(ROP_start))/len(start))
print('初始状态不调度的SR:',sum(ROP_start)/len(start)/sum(sum(h_copy1)))
print('--------------------')



#调度后的SDD
# number = []
# yy =[]
# ROP=[]
# def fcun():
#     for i in range(mapsize[0]):
#         for j in range(mapsize[1]):
#             if h_copy3[i][j] >0:
#                 if len(number)>=len(start):
#                     pass
#                 else:
#                     h_copy3[i][j] =  h_copy3[i][j]-1
#                     ROP.append(h_copy3[i][j])
#                     number.append(j)
# for i in range(99999):
#     if len(number)>=len(start):
#         break
#     else:
#         fcun()
# print(len(number))
# # for i in range(mapsize[0]):
# #     for j in range(mapsize[1]):
# #         h_copy3[i][j] = abs(h_copy3[i][j])
# # print('调度后的SDD:', sum(sum(h_copy3)))
# print(ROP)
# print('调度后的ROP:', sum(ROP)/len(start))

##调度后的ROP

num=[]
ROP = []
route = []
def ROP_ca():

    over, rest, ROUTE_LIST,a = dispatch.km_cal()
    num.append(len(over))
    for i in over:
        #route.append(ROUTE_LIST[i[0]][i[1]])
        for j in ROUTE_LIST[i[0]*a+i[1]]:
            ROP.append(hot_table[j[0]][j[1]]-1)

for i in range(999):
    if sum(num)>=util.lenth:
        break
    else:
        ROP_ca()
        print('完成调度的车辆：', sum(num))
print('调度后ROP：',sum(ROP)/util.lenth)





# ############################################   对比试验 ########################################
# index1_sdd=[]
# index2_rop=[]
#
# for i in route:
#     for j in range(7):
#         try:
#             ssss=i[j]
#         except:
#             i.append(i[-1])
# # print(route)
# for i in range(1,7):
#     for j in route:
#         index2_rop.append(hot_table[j[i][0]][j[i][1]]-1)
#     print('一个block的ROP：',sum(index2_rop)/n)

#
# def sdd(i):
#     h_copy5 = copy.deepcopy(hot_table)
#     for j in route:
#         h_copy5[j[i][0]][j[i][1]] = abs(h_copy5[j[i][0]][j[i][1]])- 1
#     for k in range(11):
#         for l in range(6):
#             h_copy5[k][l] =abs(h_copy5[k][l])
#     print('一个block的sdd：',sum(sum(h_copy5)))
#
# for i in range(1,7):
#     sdd(i)
#
#
print('--------------------')
end_time = time.perf_counter()
t = end_time - start_time
print('调度完成，总共花费%s秒' % t)


