import time
# from sqlalchemy import create_engine
import pandas as pd
import numpy as np
import pickle

#  sql_to_csv

# def time_chuo_to(ti):
#     tii = time.localtime(ti)
#     dt = time.strftime('%Y/%m/%d %H:%M:%S',tii)
#     return dt
# engine = create_engine('mysql+pymysql://root:root@localhost:3306/test')
# sql ='SELECT * FROM test.dr'
# df = pd.read_sql_query(sql, engine)
# for i in range(len(df)):
#     df.iloc[i,2] = time_chuo_to(df.iloc[i,2])
#     df.iloc[i,3] = time_chuo_to(df.iloc[i,3])
# print(df.iloc[:,2:4])
# df.to_csv('chengdu_vehicle.csv')


hour = 12

def judge_grid(n):
    x = (n[0] - 103.80635)//0.0311225625
    y = (30.89911-n[1] )//0.0244925
    return [int(y),int(x)]
def main():
    df = pd.read_csv('chengdu_vehicle.csv')
    left_start = df.loc[df['start_time'].str.contains('2016/11/1 %d:0|2016/11/1 %d:1|2016/11/1 %d:2' % (hour, hour, hour)), :]
    left_end = df.loc[df['end_time'].str.contains('2016/11/1 %d:3|2016/11/1 %d:4|2016/11/1 %d:5' % (hour, hour, hour)), :]

    #right = df.loc[df['start_time'].str.contains('2016/11/1 %d:3|2016/11/1 %d:4|2016/11/1 %d:5' % (hour, hour, hour)),:]

    longitude_start = (left_start['start_x']).values.tolist()
    latitude_start = (left_start['start_y']).values.tolist()
    start = []
    for lng,lat in zip(longitude_start,latitude_start):
        start.append([lng, lat])
    s=[]
    for i in start:
        x = judge_grid(i)
        if 16>x[0]>=0 and 16>x[1]>=0:
            s.append(x)
    start_hot_list = np.zeros((16,16))
    for i in s:
        start_hot_list[i[0]][i[1]] +=1

    longitude_end = (left_end['end_x']).values.tolist()
    latitude_end = (left_end['end_y']).values.tolist()
    end = []
    for lng,lat in zip(longitude_end,latitude_end):
        end.append([lng, lat])
    # print(start)
    e=[]
    for i in end:
        y = judge_grid(i)
        if 16>y[0]>=0 and 16>y[1]>=0:
            e.append(y)
    end_hot_list = np.zeros((16,16))
    for i in e:
        end_hot_list[i[0]][i[1]] +=1

    hot_list = start_hot_list-end_hot_list
    flow = start_hot_list+end_hot_list
    return end

if __name__ == '__main__':

    print(main())


