import order_to_block_chengdu
import order_to_block_haikou
import order_to_block_xian
import numpy as np
import pandas as pd
import sys
import copy
import time
import util
start_time = time.perf_counter()

xx,yy= util.mapsize[0],util.mapsize[1]
start,hot_table = util.start,util.hot_list

h_copy1 =copy.deepcopy(hot_table)
print(hot_table)
print(start)

print('当前可用车辆数:',len(start))
print('--------------------')


for i in range(xx):
    for j in range(yy):
        h_copy1[i][j] = abs(h_copy1[i][j])
##  不调度的ROP
ROP_start=[]
for i in start:
    ROP_start.append(hot_table[i[0]][i[1]])
print('初始状态不调度的SDD:',sum(sum(h_copy1)))
print('初始状态不调度的ROP:',(sum(ROP_start))/len(start))
print('初始状态不调度的SR:',sum(ROP_start)/len(start)/sum(sum(h_copy1)))
print('--------------------')


def first(start):
    a=[-3,-2,-1]
    area = []
    for i in a:
        for j in a:
            try:
                if hot_table[start[0]+i][start[1]+j]>=0:
                    area.append(hot_table[start[0]+i][start[1]+j])
            except:
                pass
    if len(area) == 0:
        return sum(area)
    else:
        return sum(area)/len(area)
def second(start):
    a=[-3,-2,-1]
    b = [-1,0,1]
    area = []
    for i in a:
        for j in b:
            try:
                if hot_table[start[0]+i][start[1]+j]>=0:
                    area.append(hot_table[start[0]+i][start[1]+j])
            except:
                pass
    if len(area) == 0:
        return sum(area)
    else:
        return sum(area)/len(area)
def third(start):
    a=[-3,-2,-1]
    b = [3,2,1]
    area = []
    for i in a:
        for j in b:
            try:
                if hot_table[start[0]+i][start[1]+j]>=0:
                    area.append(hot_table[start[0]+i][start[1]+j])
            except:
                pass
    if len(area) == 0:
        return sum(area)
    else:
        return sum(area)/len(area)
def four(start):
    a=[-1,0,1]
    b = [-3,-2,-1]
    area = []
    for i in a:
        for j in b:
            try:
                if hot_table[start[0]+i][start[1]+j]>=0:
                    area.append(hot_table[start[0]+i][start[1]+j])
            except:
                pass
    if len(area) == 0:
        return sum(area)
    else:
        return sum(area)/len(area)
def five(start):

    return hot_table[start[0]][start[1]]
def six(start):
    a=[-1,0,1]
    b = [3,2,1]
    area =[]
    for i in a:
        for j in b:
            try:
                if hot_table[start[0]+i][start[1]+j]>=0:
                    area.append(hot_table[start[0]+i][start[1]+j])
            except:
                pass
    if len(area) == 0:
        return sum(area)
    else:
        return sum(area)/len(area)
def seven(start):
    a=[3,2,1]
    b = [-1,-2,-3]
    area = []
    for i in a:
        for j in b:
            try:
                if hot_table[start[0]+i][start[1]+j]>=0:
                    area.append(hot_table[start[0]+i][start[1]+j])
            except:
                pass
    if len(area) == 0:
        return sum(area)
    else:
        return sum(area)/len(area)
def eight(start):
    a=[1,2,3]
    b = [-1,0,1]
    area = []
    for i in a:
        for j in b:
            try:
                if hot_table[start[0]+i][start[1]+j]>=0:
                    area.append(hot_table[start[0]+i][start[1]+j])
            except:
                pass
    if len(area) == 0:
        return sum(area)
    else:
        return sum(area)/len(area)
def nine(start):
    a=[1,2,3]
    area = []
    for i in a:
        for j in a:
            try:
                if hot_table[start[0]+i][start[1]+j]>=0:
                    area.append(hot_table[start[0]+i][start[1]+j])
            except:
                pass
    if len(area) == 0:
        return sum(area)
    else:
        return sum(area)/len(area)

def dis(start):
    a = first(start)
    b = second(start)
    c = third(start)
    d = four(start)
    e = five(start)
    f = six(start)
    g =second(start)
    h = eight(start)
    i = nine(start)
    ss = a+b+c+d+e+f+g+h+i
    area = []
    if ss == 0:
        return [start[0],start[1]]
    else:
        if 0<=start[0]-1<16 and 0<=start[1]-1<16:
            area.append([a/ss,[start[0]-1,start[1]-1]])
        if 0 <= start[0] - 1 < 16:
            area.append([b/ss,[start[0]-1,start[1]]])
        if 0 <= start[0] - 1 < 16 and 0 <= start[1] + 1 < 16:
            area.append([c/ss,[start[0]-1,start[1]+1]])
        if 0 <= start[1] - 1 < 16:
            area.append([d/ss,[start[0],start[1]-1]])
        area.append([e/ss, [start[0], start[1]]])
        if 0 <= start[1] + 1 < 16:
            area.append([f/ss,[start[0],start[1]+1]])
        if 0 <= start[0] + 1 < 16 and 0 <= start[1] - 1 < 16:
            area.append([g/ss,[start[0]+1,start[1]-1]])
        if 0 <= start[0] + 1 < 16:
            area.append([h/ss,[start[0]+1,start[1]]])
        if 0 <= start[0] + 1 < 16 and 0 <= start[1] + 1 < 16:
            area.append([i/ss,[start[0]+1,start[1]+1]])
        area.sort()
        return area[-1][1]

def dispatch(start):
    ROP = []
    endlists = []
    for i in start:
        a = dis(i)
        endlists.append(a)
    for i in endlists:
        h_copy3[i[0]][i[1]] = abs(h_copy3[i[0]][i[1]]) - 1
        ROP.append(hot_table[i[0]][i[1]])
    for i in range(xx):
        for j in range(yy):
            h_copy3[i][j] = abs(h_copy3[i][j])
    # print(h_copy3)
    print('SDD:', sum(sum(h_copy3)))
    print('ROP:',sum(ROP)/len(start))
    print('SR:',sum(ROP)/len(start)/sum(sum(h_copy3)))
    return endlists


h_copy3 = copy.deepcopy(hot_table)
a = dispatch(start)
b = dispatch(a)
c = dispatch(b)
d = dispatch(c)
e = dispatch(d)
f = dispatch(e)
end_time = time.perf_counter()
t = end_time - start_time
print('调度完成，总共花费%s秒' % t)



