import order_to_block_xian
import order_to_block_haikou
import order_to_block_chengdu
mapsize =[16,16]
start, hot_list = order_to_block_xian.main()
start=start[:10]   #这里修改车的数量
lenth= len(start)
