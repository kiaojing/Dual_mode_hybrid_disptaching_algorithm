import pickle
import numpy as np

def judge_grid(n):
    x = (n[0] - 108.92186)//0.005468125
    y = ( 34.27994-n[1] )//0.004686875
    return [int(y),int(x)]
def main():
    f1 = open(r'C:\Users\Administrator\Desktop\强化学习\5st_prediction\E2097\driver_xian_start_time_1600.pk',
              'rb')
    f2 = open(r'C:\Users\Administrator\Desktop\强化学习\5st_prediction\E2097\driver_xian_end_time_1600.pk',
              'rb')
    data1 = pickle.load(f1)
    data2 = pickle.load(f2)
    print(data1)
    la1=[]
    ln1=[]
    la2=[]
    ln2=[]
    for i in range(len(data1)):
        la1.append(data1[i]['starting_lat'])
        ln1.append(data1[i]['starting_lng'])
    for j in range(len(data2)):
        la2.append(data2[j]['dest_lat'])
        ln2.append(data2[j]['dest_lng'])
    start = []
    end =[]
    s =[]
    e =[]
    for lng,lat in zip(list(ln1),list(la1)):
        start.append([lng,lat])
    for lng,lat in zip(list(ln2),list(la2)):
        end.append([lng,lat])
    for i in start:
        x = judge_grid(i)
        if 16>x[0]>=0 and 16>x[1]>=0:
            s.append(x)
    for i in end:
        y = judge_grid(i)
        if 16>y[0]>=0 and 16>y[1]>=0:
            e.append(y)

    # 热度
    end_hot_list=np.zeros((16,16))
    start_hot_list=np.zeros((16,16))
    for i in e:
        end_hot_list[i[0]][i[1]] +=1
    for i in s:
        start_hot_list[i[0]][i[1]] +=1


    hot_list = start_hot_list-end_hot_list
    return e,hot_list
if __name__ == '__main__':
    a,b = main()
    print(a)
    print(b)
    print(len(a))
