import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split,KFold,ShuffleSplit,cross_validate
from sklearn.metrics import r2_score,explained_variance_score,mean_absolute_error,mean_squared_error
import deepforest
map = 16
kf = KFold(n_splits=5, shuffle=False)
df = pd.read_csv('xian.csv', encoding='ISO-8859-1')  ##12288 4800
TRAIN = df.iloc[12288:, :]
TEST = df.iloc[:12288, :]
a,b=13,7
time_df_test =TEST.loc[TEST['row_id'].isin([a]),:]
time_df_test =time_df_test.loc[time_df_test['col_id'].isin([b]),:]
time_df_test = np.array(time_df_test.values.tolist())
time_x_test = time_df_test[:, 3:-1]
time_y_test = time_df_test[:, -1]
normal_train=  np.array(TRAIN.values.tolist())
normal_x = normal_train[:, 3:-1]
normal_y = normal_train[:, -1]
normal_model = deepforest.CascadeForestRegressor()
normal_model.fit(normal_x,normal_y)
pre_normal = normal_model.predict(time_x_test)
time_df_train =TRAIN.loc[TRAIN['row_id'].isin([a]),:]
time_df_train =time_df_train.loc[time_df_train['col_id'].isin([b]),:]
time_df_train = np.array(time_df_train.values.tolist())
time_x_train = time_df_train[:, 3:-1]
time_y_train = time_df_train[:, -1]
time_model = deepforest.CascadeForestRegressor()
time_model.fit(time_x_train,time_y_train)
pre_time = time_model.predict(time_x_test)
# # # #  双向集成模型
val_time=[]
Stark_X_time = []
for train_index, test_index in kf.split(time_x_train):
    X_train, X_test,y_train, y_test = time_x_train[train_index], time_x_train[test_index],time_y_train[train_index], time_y_train[test_index]
    time_model = deepforest.CascadeForestRegressor()
    time_model.fit(X_train,y_train)
    p =time_model.predict(X_test)
    val_time.extend(p)
    Stark_X_time.append(time_model.predict(time_x_test))

val_normal=[]
val_normalZONG=[]
Stark_X_normal = []
for train_index, test_index in kf.split(normal_x):
    X_train, X_test,y_train, y_test = normal_x[train_index], normal_x[test_index],normal_y[train_index], normal_y[test_index]
    normal_model = deepforest.CascadeForestRegressor()
    normal_model.fit(X_train,y_train)
    q =normal_model.predict(X_test)
    Stark_X_normal.append(normal_model.predict(time_x_test))
    val_normalZONG.extend(q)
try:
    for i in range(len(val_normalZONG)):
        val_normal.append(val_normalZONG[map*map*i+a*map+b])
except:
    pass
test_x_time = np.mean(Stark_X_time,axis=0)
test_x_normal = np.mean(Stark_X_normal,axis=0)
meta_model =deepforest.CascadeForestRegressor()
meta_model.fit([[i,j] for i,j in zip(val_time,val_normal)],time_y_train)
ff=meta_model.predict([[i,j] for i,j in zip(test_x_time,test_x_normal)])
print(ff)
print('finallll',mean_absolute_error(time_y_test,ff),np.sqrt(mean_squared_error(time_y_test,ff)))
print('normal',mean_absolute_error(time_y_test,pre_normal),np.sqrt(mean_squared_error(time_y_test,pre_normal)))
print('time',mean_absolute_error(time_y_test,pre_time),np.sqrt(mean_squared_error(time_y_test,pre_time)))
